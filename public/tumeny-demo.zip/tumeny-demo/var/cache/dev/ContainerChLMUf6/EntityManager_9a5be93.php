<?php

namespace ContainerChLMUf6;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder9dd44 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerfd510 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesc24ce = [
        
    ];

    public function getConnection()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getConnection', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getMetadataFactory', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getExpressionBuilder', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'beginTransaction', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getCache', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getCache();
    }

    public function transactional($func)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'transactional', array('func' => $func), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'wrapInTransaction', array('func' => $func), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'commit', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->commit();
    }

    public function rollback()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'rollback', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getClassMetadata', array('className' => $className), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'createQuery', array('dql' => $dql), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'createNamedQuery', array('name' => $name), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'createQueryBuilder', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'flush', array('entity' => $entity), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'clear', array('entityName' => $entityName), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->clear($entityName);
    }

    public function close()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'close', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->close();
    }

    public function persist($entity)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'persist', array('entity' => $entity), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'remove', array('entity' => $entity), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'refresh', array('entity' => $entity), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'detach', array('entity' => $entity), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'merge', array('entity' => $entity), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getRepository', array('entityName' => $entityName), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'contains', array('entity' => $entity), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getEventManager', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getConfiguration', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'isOpen', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getUnitOfWork', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getProxyFactory', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'initializeObject', array('obj' => $obj), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'getFilters', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'isFiltersStateClean', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'hasFilters', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return $this->valueHolder9dd44->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerfd510 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder9dd44) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder9dd44 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder9dd44->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, '__get', ['name' => $name], $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        if (isset(self::$publicPropertiesc24ce[$name])) {
            return $this->valueHolder9dd44->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9dd44;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder9dd44;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9dd44;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder9dd44;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, '__isset', array('name' => $name), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9dd44;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder9dd44;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, '__unset', array('name' => $name), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder9dd44;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder9dd44;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, '__clone', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        $this->valueHolder9dd44 = clone $this->valueHolder9dd44;
    }

    public function __sleep()
    {
        $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, '__sleep', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;

        return array('valueHolder9dd44');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerfd510 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerfd510;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerfd510 && ($this->initializerfd510->__invoke($valueHolder9dd44, $this, 'initializeProxy', array(), $this->initializerfd510) || 1) && $this->valueHolder9dd44 = $valueHolder9dd44;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder9dd44;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder9dd44;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
