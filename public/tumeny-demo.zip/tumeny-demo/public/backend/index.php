<!DOCTYPE html>
<html lang="en">
  <?php include 'views/head.php'; ?>
  <body>
    <!-- ======= Header ======= -->
    <?php include 'views/header.php'; ?>

    <!-- ======= Sidebar ======= -->
    <?php include 'views/sidebar.php'; ?>

    <main id="main" class="main">
      <!-- Page Title -->
      <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </nav>
      </div>
      <!-- End Page Title -->

      <section class="section dashboard">
        <div class="row">
          <!-- Left side columns -->
          <div class="col-lg-8">
            <?php include 'views/indexLeftSideColumns.php'; ?>
          </div><!-- End Left side columns -->

          <!-- Right side columns -->
          <div class="col-lg-4">
            <?php include 'views/indexRightSideColumns.php'; ?>
          </div><!-- End Right side columns -->

        </div>
      </section>
    </main><!-- End #main -->

    <!-- ======= Footer/Scripts ======= -->
    <?php 
      include 'views/footer.php'; 
      include 'views/scripts.php'; 
    ?>
  </body>
</html>